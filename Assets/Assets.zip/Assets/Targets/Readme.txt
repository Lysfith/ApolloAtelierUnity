Switch Render pileline : Go to Render Pipelines folder

if you want another shader for URP version

https://assetstore.unity.com/packages/vfx/shaders/urp-simple-toon-shader-243515

URP Setting : Go to Setting folder 
(Your Quality Render)-Renderer 
Disable Depth Priming Mode.